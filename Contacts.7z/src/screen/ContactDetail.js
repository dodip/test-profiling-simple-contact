/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, { Component } from 'react';
import { View, Text, Button } from 'react-native';
import axios from 'axios';

class ContactDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      contactId: this.props.navigation.state.params.contactId,
      contact: {},
    };
  }

  componentDidMount() {
    axios.get(`https://simple-contact-crud.herokuapp.com/contact/${this.state.contactId}`)
    .then(res => {
        const resContacts = res.data.data;
        console.log(resContacts);
        this.setState({ contact: resContacts });
    })
  }

  static navigationOptions = (props) => ({
    title: 'Contacts Detail',
    headerStyle: {
       backgroundColor: '#F58220',
    },
    headerTitleStyle: {
      flex: 1,
      color: '#FFFF',
    },
  })

  deleteContact(){
    axios.delete(`https://simple-contact-crud.herokuapp.com/contact/${this.state.contactId}`)
    .then(res => {
        const resContacts = res.data.data;
        console.log(resContacts);
        this.setState({ contact: resContacts });
    })
  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#F2F4F9' }}>
        <View style={{flex: 1}}>
        <Text>Photo: {this.state.contact.photo}</Text>
        <Text>First Name: {this.state.contact.firstName}</Text>
        <Text>Last Name: {this.state.contact.lastName}</Text>
        <Text>Age: {this.state.contact.age}</Text>
        </View>
        <View style={{ padding: '5%', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <View style={{width: '50%'}}>
            <Button title="Edit" color='green' />
          </View>
          <View style={{width: '50%'}}>
            <Button title="Delete" color='red'
              onPress={() => this.deleteContact() }
            />
          </View>
        </View>
      </View>
    );
  }
}

export default ContactDetail;
