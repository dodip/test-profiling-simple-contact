const images = {
    img_contact: require('./img_contact.png') 
}

module.exports = images;